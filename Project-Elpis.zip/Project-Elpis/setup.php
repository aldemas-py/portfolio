<?php

/**
 * Elpis Counselling Centre - Database Setup Script
 * 
 * Run this script once in your browser to:
 *   1. Create the database and all tables
 *   2. Seed default data (services)
 *   3. Create the admin user with the password you set
 * 
 * After running, DELETE this file for security.
 * 
 * Default admin: admin / admin123 (you will be prompted to change)
 */

require_once __DIR__ . '/includes/config.php';

$message = '';
$messageType = '';

// Database configuration
$host = DB_HOST;
$user = DB_USER;
$pass = DB_PASS;
$dbname = DB_NAME;

// Only run setup if requested
$isSetup = isset($_POST['setup']) || isset($_GET['run']);

if ($isSetup) {
    try {
        // Connect without database first
        $pdo = new PDO("mysql:host=$host;charset=utf8mb4", $user, $pass, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);

        // Create database
        $pdo->exec("CREATE DATABASE IF NOT EXISTS `$dbname` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        $pdo->exec("USE `$dbname`");

        // Drop existing tables for a fresh setup (only if requested)
        if (isset($_POST['force'])) {
            $pdo->exec("SET FOREIGN_KEY_CHECKS = 0");
            $pdo->exec("DROP TABLE IF EXISTS event_bookings, testimonials, contacts, appointments, events, articles, services, admin_users");
            $pdo->exec("SET FOREIGN_KEY_CHECKS = 1");
        }

        // Create tables
        $pdo->exec("CREATE TABLE IF NOT EXISTS admin_users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(50) NOT NULL UNIQUE,
            password_hash VARCHAR(255) NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        $pdo->exec("CREATE TABLE IF NOT EXISTS services (
            id INT AUTO_INCREMENT PRIMARY KEY,
            title VARCHAR(200) NOT NULL,
            description TEXT,
            icon VARCHAR(100) DEFAULT 'heart',
            display_order INT DEFAULT 0,
            is_active TINYINT(1) DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        $pdo->exec("CREATE TABLE IF NOT EXISTS appointments (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(100) NOT NULL,
            email VARCHAR(100) NOT NULL,
            phone VARCHAR(20) NOT NULL,
            service VARCHAR(200) DEFAULT NULL,
            preferred_date DATE DEFAULT NULL,
            message TEXT,
            status ENUM('pending', 'contacted', 'completed', 'cancelled') DEFAULT 'pending',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        $pdo->exec("CREATE TABLE IF NOT EXISTS articles (
            id INT AUTO_INCREMENT PRIMARY KEY,
            title VARCHAR(255) NOT NULL,
            slug VARCHAR(255) NOT NULL UNIQUE,
            content LONGTEXT,
            excerpt TEXT,
            author VARCHAR(100) DEFAULT 'Elpis Counselling Centre',
            image VARCHAR(255) DEFAULT NULL,
            category VARCHAR(100) DEFAULT 'General',
            is_published TINYINT(1) DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        $pdo->exec("CREATE TABLE IF NOT EXISTS events (
            id INT AUTO_INCREMENT PRIMARY KEY,
            title VARCHAR(255) NOT NULL,
            description TEXT,
            event_date DATE NOT NULL,
            event_time VARCHAR(50) DEFAULT NULL,
            venue VARCHAR(255) DEFAULT NULL,
            price DECIMAL(10,2) DEFAULT 0.00,
            image VARCHAR(255) DEFAULT NULL,
            max_participants INT DEFAULT NULL,
            is_published TINYINT(1) DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        $pdo->exec("CREATE TABLE IF NOT EXISTS event_bookings (
            id INT AUTO_INCREMENT PRIMARY KEY,
            event_id INT NOT NULL,
            name VARCHAR(100) NOT NULL,
            email VARCHAR(100) NOT NULL,
            phone VARCHAR(20) NOT NULL,
            mpesa_code VARCHAR(50) DEFAULT NULL,
            amount DECIMAL(10,2) DEFAULT 0.00,
            status ENUM('pending', 'confirmed', 'cancelled', 'refunded') DEFAULT 'pending',
            booking_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        $pdo->exec("CREATE TABLE IF NOT EXISTS testimonials (
            id INT AUTO_INCREMENT PRIMARY KEY,
            client_name VARCHAR(100) NOT NULL,
            client_role VARCHAR(100) DEFAULT NULL,
            content TEXT NOT NULL,
            rating TINYINT DEFAULT 5,
            image VARCHAR(255) DEFAULT NULL,
            is_approved TINYINT(1) DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        $pdo->exec("CREATE TABLE IF NOT EXISTS contacts (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(100) NOT NULL,
            email VARCHAR(100) NOT NULL,
            phone VARCHAR(20) DEFAULT NULL,
            subject VARCHAR(255) DEFAULT NULL,
            message TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        // Seed services if empty
        $count = $pdo->query("SELECT COUNT(*) FROM services")->fetchColumn();
        if ($count == 0) {
            $services = [
                ['Career Counselling', 'Guidance and support for career transitions, job search strategies, and professional development planning.', 'briefcase'],
                ['Couple Counselling', 'Strengthen your relationship through improved communication, conflict resolution, and mutual understanding.', 'heart'],
                ['Children & Adolescent Counselling', 'Specialized support for young people dealing with family, school, or personal challenges.', 'child'],
                ['Pregnancy Crisis Support', 'Compassionate care and guidance for those navigating unplanned pregnancy or pregnancy-related concerns.', 'baby'],
                ['Addiction Counselling', 'Recovery support for drug, alcohol, food, gambling, social media, and other addictive behaviours.', 'shield'],
                ['Family Counselling', 'Improve family dynamics, communication patterns, and strengthen bonds between family members.', 'users'],
                ['Group Counselling', 'Therapeutic group sessions that provide mutual support and shared growth experiences.', 'people'],
                ['HIV/AIDS Counselling', 'Confidential support for individuals and families affected by HIV/AIDS, including testing guidance.', 'ribbon'],
                ['Loss, Grief & Bereavement Counselling', 'Navigate the difficult journey of loss with compassionate, professional support.', 'flower'],
                ['Marriage Counselling', 'Deepen your marital bond, address challenges, and build a stronger partnership.', 'ring'],
                ['Mid-Life Crisis Counselling', 'Navigate life transitions, identity questions, and existential concerns during mid-life.', 'compass'],
                ['Parent-Child Relationship Counselling', 'Improve understanding and connection between parents and children across all ages.', 'tree'],
                ['Premarital Counselling', 'Build a strong foundation for your marriage with evidence-based premarital guidance.', 'star'],
                ['Peer Counselling', 'Trained peer support for those who benefit from shared lived experiences.', 'handshake'],
                ['Psycho-Education', 'Workshops on anger management, stress management, assertiveness, and problem-solving skills.', 'book'],
                ['Personality Issues Support', 'Therapeutic support for anxiety, phobias, and related personality concerns.', 'brain'],
                ['Sexual Problems Counselling', 'Confidential, sensitive support for sexual health and relationship concerns.', 'lock'],
                ['Suicide Intervention', 'Immediate, compassionate crisis intervention and ongoing support for those in distress.', 'phone'],
                ['Trauma Counselling', 'Trauma-informed care using evidence-based modalities including EMDR and narrative therapy.', 'umbrella'],
            ];

            $stmt = $pdo->prepare("INSERT INTO services (title, description, icon, display_order) VALUES (?, ?, ?, ?)");
            foreach ($services as $i => $svc) {
                $stmt->execute([$svc[0], $svc[1], $svc[2], $i + 1]);
            }
        }

        // Create admin user
        $username = trim($_POST['admin_username'] ?? 'admin');
        $password = $_POST['admin_password'] ?? 'admin123';

        if (strlen($password) < 6) {
            throw new Exception('Password must be at least 6 characters.');
        }

        $passwordHash = password_hash($password, PASSWORD_BCRYPT);

        // Check if admin exists; update if exists, else insert
        $check = $pdo->prepare("SELECT id FROM admin_users WHERE username = ?");
        $check->execute([$username]);
        if ($check->fetch()) {
            $stmt = $pdo->prepare("UPDATE admin_users SET password_hash = ? WHERE username = ?");
            $stmt->execute([$passwordHash, $username]);
        } else {
            $stmt = $pdo->prepare("INSERT INTO admin_users (username, password_hash) VALUES (?, ?)");
            $stmt->execute([$username, $passwordHash]);
        }

        $message = "Setup completed successfully! Database and tables created. Admin login: <strong>" . htmlspecialchars($username) . "</strong> / (password you set). Your admin panel is at <a href='" . SITE_URL . "/admin/index.php'>admin login</a>.";
        $messageType = 'success';
    } catch (Exception $e) {
        $message = "Setup failed: " . $e->getMessage();
        $messageType = 'error';
    }
}

// Check if database already has tables
$dbReady = false;
try {
    $pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4", DB_USER, DB_PASS);
    $result = $pdo->query("SHOW TABLES LIKE 'admin_users'");
    $dbReady = $result->fetchColumn() !== false;
} catch (Exception $e) {
    $dbReady = false;
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Database Setup - Elpis Counselling Centre</title>
    <style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    body {
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        background: #3F5195;
        min-height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 2rem;
    }

    .setup-container {
        background: #fff;
        border-radius: 20px;
        padding: 3rem;
        max-width: 520px;
        width: 100%;
        box-shadow: 0 20px 60px rgba(0, 0, 0, 0.2);
    }

    h1 {
        font-size: 1.4rem;
        color: #3F5195;
        margin-bottom: 0.5rem;
    }

    p {
        color: #666;
        font-size: 0.9rem;
        margin-bottom: 1.5rem;
        line-height: 1.6;
    }

    .form-group {
        margin-bottom: 1.2rem;
    }

    .form-group label {
        display: block;
        margin-bottom: 0.4rem;
        font-weight: 600;
        font-size: 0.9rem;
        color: #3F5195;
    }

    .form-control {
        width: 100%;
        padding: 0.8rem 1rem;
        border: 2px solid #D7DDD9;
        border-radius: 10px;
        font-size: 0.95rem;
        font-family: inherit;
        transition: border-color 0.3s ease;
    }

    .form-control:focus {
        outline: none;
        border-color: #4FA08A;
    }

    .btn {
        width: 100%;
        padding: 0.8rem;
        background: #4FA08A;
        color: #fff;
        border: none;
        border-radius: 10px;
        font-size: 1rem;
        font-weight: 600;
        cursor: pointer;
        transition: background 0.3s ease;
    }

    .btn:hover {
        background: #3F5195;
    }

    .alert {
        padding: 0.8rem 1rem;
        border-radius: 10px;
        margin-bottom: 1.5rem;
        font-size: 0.9rem;
        line-height: 1.5;
    }

    .alert-success {
        background: #d4edda;
        color: #155724;
        border: 1px solid #c3e6cb;
    }

    .alert-error {
        background: #f8d7da;
        color: #721c24;
        border: 1px solid #f5c6cb;
    }

    .status {
        background: #EAF4F1;
        padding: 0.8rem 1rem;
        border-radius: 10px;
        margin-bottom: 1.5rem;
        font-size: 0.85rem;
        color: #3F5195;
    }

    .checkbox-label {
        display: flex;
        align-items: center;
        gap: 0.5rem;
        font-size: 0.85rem;
        color: #666;
        cursor: pointer;
    }

    .checkbox-label input {
        cursor: pointer;
    }

    .note {
        background: #fff3cd;
        color: #856404;
        padding: 0.8rem 1rem;
        border-radius: 10px;
        font-size: 0.85rem;
        margin-top: 1.5rem;
        line-height: 1.5;
    }
    </style>
</head>

<body>
    <div class="setup-container">
        <h1>Elpis Counselling Centre</h1>
        <p>Database setup wizard. This creates the database, tables, and admin account for your website.</p>

        <?php if ($message): ?>
        <div class="alert alert-<?php echo $messageType; ?>"><?php echo $message; ?></div>
        <?php endif; ?>

        <?php if ($dbReady): ?>
        <div class="status">&#9989; Database already set up. You can update the admin password below or use the existing
            setup.</div>
        <?php endif; ?>

        <form method="POST" action="">
            <div class="form-group">
                <label for="admin_username">Admin Username</label>
                <input type="text" id="admin_username" name="admin_username" class="form-control" value="admin">
            </div>
            <div class="form-group">
                <label for="admin_password">Admin Password (min 6 chars)</label>
                <input type="text" id="admin_password" name="admin_password" class="form-control" value="admin123">
            </div>
            <div class="form-group">
                <label class="checkbox-label">
                    <input type="checkbox" name="force" value="1">
                    Force reset (drop all existing tables and recreate)
                </label>
            </div>
            <button type="submit" name="setup" class="btn">Run Setup</button>
        </form>

        <div class="note">
            <strong>Security:</strong> After running this setup, please delete this <code>setup.php</code> file from
            your
            server. Default credentials are <strong>admin / admin123</strong> — change them on first login.
        </div>
    </div>
</body>

</html>